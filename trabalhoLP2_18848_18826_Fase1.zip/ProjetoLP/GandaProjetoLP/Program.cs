﻿// -------------------------------------------------
//-----------------------------------------------------------------------
// <copyright file="Program.cs" company="IPCA">
//     Copyright IPCA. All rights reserved.
// </copyright>
// <date> 24/04/2020 </date>
// <author> ZeCosgrove & AndreCardoso </author>
// <version>1.0</version>
// <desc>Projeto de LP2</desc>
//-------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GandaProjetoLP.Classes;

namespace GandaProjetoLP
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadLine();
        }
    }
}
