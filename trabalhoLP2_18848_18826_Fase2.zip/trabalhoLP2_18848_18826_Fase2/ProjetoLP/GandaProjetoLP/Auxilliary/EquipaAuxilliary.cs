﻿/*
*	<copyright file="ProjetoLP.Auxilliary.cs" company="IPCA">
*		Copyright (c) 2020 All Rights Reserved
*	</copyright>
* 	<author>Andre</author>
*   <date>5/21/2020 7:15:19 PM</date>
*	<description></description>
**/
using System;

namespace ProjetoLP.Auxilliary
{
    public interface IEquipaAuxilliary
    {
        //void PrintJogadores();
    }
    /// <summary>
    /// Purpose:
    /// Created by: Andre
    /// Created on: 5/21/2020 7:15:19 PM
    /// </summary>
    /// <remarks></remarks>
    /// <example></example>
    public class EquipaAuxilliary : IEquipaAuxilliary
    {
        #region Methods

        #region Constructors

        /// <summary>
        /// The default Constructor.
        /// </summary>
        public EquipaAuxilliary()
        {
        }

        #endregion

        #region Properties

        //public void PrintJogadores() { }

        #endregion



        #region Overrides
        #endregion

        #region OtherMethods
        #endregion

        #region Destructor
        /// <summary>
        /// The destructor.
        /// </summary>
        ~EquipaAuxilliary()
        {
        }
        #endregion

        #endregion
    }
}
